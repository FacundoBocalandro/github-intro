public abstract class Measurement {
    public abstract int compare(Measurement measurement);
}
